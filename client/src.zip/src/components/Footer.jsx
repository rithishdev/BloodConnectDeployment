import React from 'react';

export default function Footer({ onNavigateTab, onOpenAuthModal }) {
  return (
    <footer className="bg-slate-900 text-slate-400 pt-10 pb-8 border-t border-slate-800 mt-12">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Col 1: Brand & Bio */}
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-brand-600 rounded-xl flex items-center justify-center text-white">
                <i className="fa-solid fa-droplet text-sm"></i>
              </div>
              <span className="text-lg font-bold text-white">BloodConnect</span>
            </div>
            <p className="text-xs leading-relaxed text-slate-400">
              Connecting life-saving blood donors with patients and hospitals in real-time. Built to save lives faster during emergency golden hours.
            </p>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-3 text-xs uppercase tracking-wider">
              Quick Links
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button
                  onClick={() => onNavigateTab('available')}
                  className="hover:text-white transition"
                >
                  Available Inventory
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('search')}
                  className="hover:text-white transition"
                >
                  Find Donors
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('requests')}
                  className="hover:text-white transition"
                >
                  Emergency Requests
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('hospitals')}
                  className="hover:text-white transition"
                >
                  Partner Hospitals
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Portals & Admin */}
          <div>
            <h4 className="text-white font-semibold mb-3 text-xs uppercase tracking-wider">
              Portals & Admin
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button
                  onClick={() => onNavigateTab('donor-portal')}
                  className="hover:text-white transition"
                >
                  Donor Dashboard
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('patient-portal')}
                  className="hover:text-white transition"
                >
                  Patient Request Portal
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('admin')}
                  className="hover:text-white transition"
                >
                  Hospital Admin Login
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('analytics')}
                  className="hover:text-white transition"
                >
                  Supply Analytics
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: 24/7 Hotline */}
          <div>
            <h4 className="text-white font-semibold mb-3 text-xs uppercase tracking-wider">
              24/7 Emergency Hotline
            </h4>
            <div className="bg-slate-800 p-3.5 rounded-xl border border-slate-700 text-xs">
              <div className="flex items-center text-brand-400 font-bold mb-1 text-sm">
                <i className="fa-solid fa-phone-volume mr-2"></i> 1-800-BLOOD-NOW
              </div>
              <p className="text-[11px] text-slate-400">
                Direct hotline for urgent trauma surgery & whole blood dispatch.
              </p>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800 text-xs text-center text-slate-500">
          &copy; {new Date().getFullYear()} BloodConnect Emergency Network. All rights reserved. Live MongoDB Atlas grid.
        </div>
      </div>
    </footer>
  );
}
