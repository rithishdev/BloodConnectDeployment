import React from 'react';

const PAGES = [
  { id: 'home', label: 'Home', icon: 'fa-house' },
  { id: 'available', label: 'Find Blood', icon: 'fa-box-archive' },
  { id: 'search', label: 'Search Donors', icon: 'fa-users' },
  { id: 'requests', label: 'Blood Requests', icon: 'fa-notes-medical', badge: true },
  { id: 'hospitals', label: 'Hospitals', icon: 'fa-hospital' },
  { id: 'donor-portal', label: 'Donor Portal', icon: 'fa-user-nurse' },
  { id: 'patient-portal', label: 'Patient Portal', icon: 'fa-hospital-user' },
  { id: 'admin', label: 'Admin Dashboard', icon: 'fa-chart-line' },
  { id: 'analytics', label: 'Supply Analytics', icon: 'fa-chart-pie' }
];

export default function Sidebar({
  activeTab,
  setActiveTab,
  onOpenRequest,
  onOpenRegister,
  pendingCriticalCount = 0,
  mobileOpen = false,
  setMobileOpen
}) {
  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Fixed Left Sidebar */}
      <aside
        id="sidebar-nav"
        className={`w-64 bg-slate-900 text-slate-300 flex-shrink-0 flex flex-col justify-between fixed top-0 bottom-0 left-0 z-50 transition-transform duration-300 shadow-xl border-r border-slate-800 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div>
          {/* SIDEBAR BRAND LOGO */}
          <div className="p-5 border-b border-slate-800 flex items-center justify-between">
            <div
              className="flex items-center space-x-3 cursor-pointer"
              onClick={() => {
                setActiveTab('home');
                setMobileOpen(false);
              }}
            >
              <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-brand-500/30 blood-drop-pulse">
                <i className="fa-solid fa-droplet text-xl"></i>
              </div>
              <div>
                <span className="text-xl font-black tracking-tight text-white">
                  Blood<span className="text-brand-500">Connect</span>
                </span>
                <span className="block text-[9px] font-semibold uppercase tracking-widest text-slate-400 -mt-1">
                  Lifesaving Grid
                </span>
              </div>
            </div>

            {/* Mobile close button */}
            <button
              onClick={() => setMobileOpen(false)}
              className="lg:hidden text-slate-400 hover:text-white p-1"
            >
              <i className="fa-solid fa-xmark text-lg"></i>
            </button>
          </div>

          {/* SIDEBAR NAVIGATION MENU */}
          <div className="p-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-3 py-2">
              Navigation Views
            </div>
            <nav className="space-y-1">
              {PAGES.map((p) => {
                const isActive = activeTab === p.id;
                return (
                  <button
                    key={p.id}
                    onClick={() => {
                      setActiveTab(p.id);
                      setMobileOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-medium transition flex items-center justify-between ${
                      isActive
                        ? 'bg-brand-600 text-white font-bold shadow-md shadow-brand-600/30'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <i className={`fa-solid ${p.icon} text-sm w-5 text-center ${isActive ? 'text-white' : 'text-slate-400'}`}></i>
                      <span>{p.label}</span>
                    </div>
                    {p.badge && pendingCriticalCount > 0 && (
                      <span className="bg-red-500 text-white text-[10px] font-extrabold px-1.5 py-0.2 rounded-full animate-pulse">
                        {pendingCriticalCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* SIDEBAR FOOTER ACTIONS */}
        <div className="p-4 border-t border-slate-800 space-y-2">
          <button
            onClick={() => {
              onOpenRequest();
              setMobileOpen(false);
            }}
            className="w-full bg-brand-600 hover:bg-brand-700 text-white font-semibold py-2.5 px-3 rounded-xl text-xs transition flex items-center justify-center shadow-md active:scale-95"
          >
            <i className="fa-solid fa-hand-holding-medical mr-2"></i> Request Blood
          </button>
          <button
            onClick={() => {
              onOpenRegister();
              setMobileOpen(false);
            }}
            className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold py-2.5 px-3 rounded-xl text-xs transition flex items-center justify-center border border-slate-700 active:scale-95"
          >
            <i className="fa-solid fa-heart-pulse mr-2 text-brand-500"></i> Become Donor
          </button>
        </div>
      </aside>
    </>
  );
}
