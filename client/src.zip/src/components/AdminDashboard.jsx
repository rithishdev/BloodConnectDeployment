import React, { useState, useEffect } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export default function AdminDashboard({
  currentUser,
  token,
  onLogin,
  onRefreshData,
  onOpenAuthModal
}) {
  const [adminTab, setAdminTab] = useState('queue'); // 'queue' | 'inventory' | 'hospitals' | 'donors'
  const [overview, setOverview] = useState(null);
  const [requests, setRequests] = useState([]);
  const [hospitals, setHospitals] = useState([]);
  const [donors, setDonors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [toastMsg, setToastMsg] = useState(null);

  // New Hospital Form Modal
  const [showAddHospital, setShowAddHospital] = useState(false);
  const [hospitalForm, setHospitalForm] = useState({
    name: '',
    city: 'Metro City',
    address: '',
    phone: '',
    emergencyHotline: ''
  });

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const headers = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const [ovRes, reqRes, hospRes, donRes] = await Promise.all([
        fetch('/api/analytics/overview', { headers }).then((r) => r.json()).catch(() => null),
        fetch('/api/requests', { headers }).then((r) => r.json()).catch(() => null),
        fetch('/api/hospitals', { headers }).then((r) => r.json()).catch(() => null),
        fetch('/api/donors', { headers }).then((r) => r.json()).catch(() => null)
      ]);

      if (ovRes?.data) setOverview(ovRes.data);
      else if (ovRes) setOverview(ovRes);

      if (reqRes?.success && Array.isArray(reqRes.data)) setRequests(reqRes.data);
      if (hospRes?.success && Array.isArray(hospRes.data)) setHospitals(hospRes.data);
      if (donRes?.success && Array.isArray(donRes.data)) setDonors(donRes.data);
    } catch (err) {
      console.warn('Admin load note:', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, [token]);

  const handleAction = async (requestId, action) => {
    try {
      const headers = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/requests/${requestId}/${action}`, {
        method: 'PATCH',
        headers
      });
      const data = await res.json();
      if (data.success) {
        setToastMsg(`Request ${action.toUpperCase()} successfully!`);
        loadAdminData();
        if (onRefreshData) onRefreshData();
      } else {
        setToastMsg(data.message || 'Action failed');
      }
    } catch (err) {
      setToastMsg('Error completing action');
    }
    setTimeout(() => setToastMsg(null), 3500);
  };

  const handleAddHospitalSubmit = async (e) => {
    e.preventDefault();
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/hospitals', {
        method: 'POST',
        headers,
        body: JSON.stringify(hospitalForm)
      });
      const data = await res.json();
      if (data.success) {
        setToastMsg('Hospital added to network!');
        setShowAddHospital(false);
        setHospitalForm({ name: '', city: 'Metro City', address: '', phone: '', emergencyHotline: '' });
        loadAdminData();
      } else {
        setToastMsg(data.message || 'Failed to add hospital');
      }
    } catch (err) {
      setToastMsg('Error adding hospital');
    }
    setTimeout(() => setToastMsg(null), 3500);
  };

  const pendingRequests = requests.filter((r) => r.status === 'PENDING');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl text-xs font-semibold flex items-center space-x-2 border border-slate-700 animate-bounce">
          <i className="fa-solid fa-circle-check text-brand-500"></i>
          <span>{toastMsg}</span>
        </div>
      )}

      {/* ─── HEADER matching HTML ──────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900">Hospital Administration Hub</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage dispatch approvals, inventory adjustments, and emergency grid alerts.
          </p>
        </div>
        <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-1.5 rounded-full flex items-center shadow-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-ping"></span>
          System Online
        </span>
      </div>

      {/* ─── METRICS OVERVIEW matching HTML ────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-xs text-slate-400 font-bold uppercase">Total Stock</div>
          <div className="text-2xl font-black text-slate-900 mt-1">
            {overview?.totalUnitsAvailable || 116} Units
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Across network banks</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-xs text-slate-400 font-bold uppercase">Pending Approvals</div>
          <div className="text-2xl font-black text-amber-500 mt-1">
            {pendingRequests.length} Requests
          </div>
          <p className="text-[11px] text-amber-600 mt-0.5">Awaiting triage</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-xs text-slate-400 font-bold uppercase">Active Donors</div>
          <div className="text-2xl font-black text-brand-600 mt-1">
            {overview?.totalDonors || donors.length || 9} Registered
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Proximity indexed</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-xs text-slate-400 font-bold uppercase">Partner Hospitals</div>
          <div className="text-2xl font-black text-emerald-600 mt-1">
            {overview?.registeredHospitals || hospitals.length || 2} Units Ready
          </div>
          <p className="text-[11px] text-emerald-600 mt-0.5">Accredited trauma nodes</p>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex border-b border-slate-200 space-x-4 text-xs font-bold">
        {[
          { id: 'queue', label: 'Emergency Approval Queue' },
          { id: 'hospitals', label: 'Manage Hospitals' },
          { id: 'donors', label: 'Registered Donors' }
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setAdminTab(t.id)}
            className={`pb-3 border-b-2 transition ${
              adminTab === t.id
                ? 'border-brand-600 text-brand-600'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ─── TAB 1: PENDING APPROVALS TABLE matching HTML ──────────────── */}
      {adminTab === 'queue' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="p-5 border-b border-slate-200 flex justify-between items-center">
            <h3 className="font-bold text-slate-900">Emergency Dispatch Approval Queue</h3>
            <button
              onClick={loadAdminData}
              className="text-xs text-brand-600 font-bold hover:underline"
            >
              Refresh List
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 uppercase text-slate-400 font-bold">
                <tr>
                  <th className="p-4">Patient / ID</th>
                  <th className="p-4">Blood Group</th>
                  <th className="p-4">Units</th>
                  <th className="p-4">Hospital</th>
                  <th className="p-4">Urgency</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {requests.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="p-8 text-center text-slate-400">
                      No requests currently in dispatch queue.
                    </td>
                  </tr>
                ) : (
                  requests.map((r) => (
                    <tr key={r._id || r.id} className="hover:bg-slate-50 transition">
                      <td className="p-4 font-bold text-slate-800">
                        {r.patientName}
                        <span className="block text-[10px] text-slate-400 font-normal">
                          {String(r._id || r.id).slice(-6)}
                        </span>
                      </td>
                      <td className="p-4 font-black text-brand-600 text-sm">{r.bloodGroup}</td>
                      <td className="p-4">{r.unitsRequired || 1} Units</td>
                      <td className="p-4 truncate max-w-[160px]">{r.hospitalName}</td>
                      <td className="p-4">
                        <span
                          className={`font-bold px-2 py-0.5 rounded text-[10px] ${
                            (r.urgency || '').toUpperCase() === 'CRITICAL'
                              ? 'bg-red-100 text-red-700'
                              : 'bg-amber-100 text-amber-700'
                          }`}
                        >
                          {r.urgency || 'STANDARD'}
                        </span>
                      </td>
                      <td className="p-4">
                        <span className="font-semibold text-slate-700">{r.status}</span>
                      </td>
                      <td className="p-4 text-right space-x-2">
                        {r.status === 'PENDING' ? (
                          <>
                            <button
                              onClick={() => handleAction(r._id || r.id, 'approve')}
                              className="bg-emerald-600 text-white font-bold px-3 py-1.5 rounded-lg hover:bg-emerald-700 transition active:scale-95"
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => handleAction(r._id || r.id, 'reject')}
                              className="bg-slate-200 text-slate-700 font-bold px-3 py-1.5 rounded-lg hover:bg-slate-300 transition active:scale-95"
                            >
                              Reject
                            </button>
                          </>
                        ) : r.status === 'ACCEPTED' ? (
                          <button
                            onClick={() => handleAction(r._id || r.id, 'fulfill')}
                            className="bg-brand-600 text-white font-bold px-3 py-1.5 rounded-lg hover:bg-brand-700 transition active:scale-95"
                          >
                            Mark Fulfilled
                          </button>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ─── TAB 2: HOSPITALS MANAGEMENT ───────────────────────────────── */}
      {adminTab === 'hospitals' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-900 text-lg">Hospital Directory Management</h3>
            <button
              onClick={() => setShowAddHospital(true)}
              className="bg-brand-600 hover:bg-brand-700 text-white font-bold px-4 py-2 rounded-xl text-xs transition shadow-md active:scale-95"
            >
              <i className="fa-solid fa-plus mr-1.5"></i> Add Hospital
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 uppercase text-slate-400 font-bold">
                  <tr>
                    <th className="p-4">Hospital Name</th>
                    <th className="p-4">City</th>
                    <th className="p-4">Phone</th>
                    <th className="p-4">Inventory Units</th>
                    <th className="p-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {hospitals.map((h) => {
                    const totalUnits = Object.values(h.bloodInventory || {}).reduce(
                      (acc, v) => acc + (Number(v) || 0),
                      0
                    );
                    return (
                      <tr key={h._id} className="hover:bg-slate-50 transition">
                        <td className="p-4 font-bold text-slate-900">{h.name}</td>
                        <td className="p-4">{h.city}</td>
                        <td className="p-4">{h.phone || h.emergencyHotline || '—'}</td>
                        <td className="p-4 font-extrabold text-brand-600">{totalUnits} Units</td>
                        <td className="p-4">
                          <span className="bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold text-[10px]">
                            Verified Bank
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ─── TAB 3: REGISTERED DONORS ──────────────────────────────────── */}
      {adminTab === 'donors' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="p-5 border-b border-slate-200">
            <h3 className="font-bold text-slate-900">Registered Donors Index</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 uppercase text-slate-400 font-bold">
                <tr>
                  <th className="p-4">Donor Name</th>
                  <th className="p-4">Blood Group</th>
                  <th className="p-4">City</th>
                  <th className="p-4">Phone</th>
                  <th className="p-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {donors.map((d) => (
                  <tr key={d._id || d.id} className="hover:bg-slate-50 transition">
                    <td className="p-4 font-bold text-slate-900">{d.name}</td>
                    <td className="p-4 font-black text-brand-600">{d.bloodGroup}</td>
                    <td className="p-4">{d.city || 'Metro City'}</td>
                    <td className="p-4">{d.phone || '+1 (555) 019-9000'}</td>
                    <td className="p-4">
                      <span
                        className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          d.isAvailable !== false ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {d.isAvailable !== false ? 'Available' : 'Resting'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Hospital Modal */}
      {showAddHospital && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setShowAddHospital(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-slate-900">Register New Partner Hospital</h3>
              <button onClick={() => setShowAddHospital(false)} className="text-slate-400 hover:text-slate-600">
                <i className="fa-solid fa-xmark text-lg"></i>
              </button>
            </div>
            <form onSubmit={handleAddHospitalSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Hospital Name</label>
                <input
                  type="text"
                  required
                  value={hospitalForm.name}
                  onChange={(e) => setHospitalForm({ ...hospitalForm, name: e.target.value })}
                  placeholder="e.g. Memorial Health Institute"
                  className="w-full border rounded-xl p-2.5 text-sm bg-slate-50"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">City</label>
                <input
                  type="text"
                  required
                  value={hospitalForm.city}
                  onChange={(e) => setHospitalForm({ ...hospitalForm, city: e.target.value })}
                  placeholder="e.g. Chicago"
                  className="w-full border rounded-xl p-2.5 text-sm bg-slate-50"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Address</label>
                <input
                  type="text"
                  value={hospitalForm.address}
                  onChange={(e) => setHospitalForm({ ...hospitalForm, address: e.target.value })}
                  placeholder="e.g. 100 Hospital Way"
                  className="w-full border rounded-xl p-2.5 text-sm bg-slate-50"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={hospitalForm.phone}
                  onChange={(e) => setHospitalForm({ ...hospitalForm, phone: e.target.value })}
                  placeholder="+1 (555) 000-0000"
                  className="w-full border rounded-xl p-2.5 text-sm bg-slate-50"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-brand-600 text-white font-bold py-3 rounded-xl hover:bg-brand-700 text-sm shadow-md"
              >
                Save Hospital
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
