import React, { useState, useEffect, useMemo } from 'react';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export default function AvailableBloodView({ onOpenRequest, onOpenRegister, onNavigateHospitals }) {
  const [hospitals, setHospitals] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters matching bloodconnect_platform.html
  const [filterGroup, setFilterGroup] = useState('ALL');
  const [filterCity, setFilterCity] = useState('ALL');
  const [filterUrgency, setFilterUrgency] = useState('ALL');

  const loadHospitals = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/hospitals');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setHospitals(data.data);
      }
    } catch (err) {
      console.warn('Hospital fetch notice:', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadHospitals();
  }, []);

  // Extract unique cities
  const cities = useMemo(() => {
    const set = new Set();
    hospitals.forEach((h) => {
      if (h.city) set.add(h.city);
    });
    return Array.from(set).sort();
  }, [hospitals]);

  // Expand hospital blood inventory into individual blood inventory cards
  const inventoryCards = useMemo(() => {
    const list = [];
    hospitals.forEach((h) => {
      const inv = h.bloodInventory || {};
      BLOOD_GROUPS.forEach((bg) => {
        const units = inv[bg] !== undefined ? inv[bg] : 0;
        let status = 'Available';
        let urgency = 'Normal';
        if (units <= 3) {
          status = 'Critical Low';
          urgency = 'Critical';
        } else if (units < 10) {
          status = 'Low Stock';
          urgency = 'Warning';
        }

        list.push({
          id: `${h._id}_${bg}`,
          bloodType: bg,
          units,
          hospital: h.name,
          city: h.city || 'Metro City',
          phone: h.phone || h.emergencyHotline || '',
          status,
          urgency,
          lastUpdated: 'Live Database'
        });
      });
    });
    return list;
  }, [hospitals]);

  // Apply filters
  const filteredItems = useMemo(() => {
    return inventoryCards.filter((item) => {
      if (filterGroup !== 'ALL' && item.bloodType !== filterGroup) return false;
      if (filterCity !== 'ALL' && item.city !== filterCity) return false;
      if (filterUrgency === 'Available' && item.units < 10) return false;
      if (filterUrgency === 'Low' && (item.units < 4 || item.units >= 10)) return false;
      if (filterUrgency === 'Critical' && item.units > 3) return false;
      return true;
    });
  }, [inventoryCards, filterGroup, filterCity, filterUrgency]);

  const resetFilters = () => {
    setFilterGroup('ALL');
    setFilterCity('ALL');
    setFilterUrgency('ALL');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900">Available Blood Stock Inventory</h1>
          <p className="text-sm text-slate-500 mt-1">
            Real-time stock verified across accredited regional hospital blood banks.
          </p>
        </div>
        <button
          onClick={onOpenRequest}
          className="bg-brand-600 hover:bg-brand-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm shadow-md transition flex items-center active:scale-95"
        >
          <i className="fa-solid fa-plus-circle mr-2"></i> Post Emergency Request
        </button>
      </div>

      {/* FILTER BAR matching HTML */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Blood Group</label>
            <select
              value={filterGroup}
              onChange={(e) => setFilterGroup(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="ALL">All Blood Groups</option>
              {BLOOD_GROUPS.map((bg) => (
                <option key={bg} value={bg}>
                  {bg}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">City / Location</label>
            <select
              value={filterCity}
              onChange={(e) => setFilterCity(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="ALL">All Cities</option>
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Stock Level Status</label>
            <select
              value={filterUrgency}
              onChange={(e) => setFilterUrgency(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="Available">Available (&gt;10 Units)</option>
              <option value="Low">Low Stock (4–9 Units)</option>
              <option value="Critical">Critical Shortage (≤3 Units)</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={resetFilters}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium py-2 px-4 rounded-xl text-sm transition flex items-center justify-center active:scale-95"
            >
              <i className="fa-solid fa-rotate mr-1.5"></i> Reset Filters
            </button>
          </div>
        </div>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="py-12 text-center text-slate-400 text-sm">
          <i className="fa-solid fa-circle-notch fa-spin text-brand-600 text-2xl mb-2"></i>
          <p>Syncing blood inventory from partner hospital banks...</p>
        </div>
      )}

      {/* Empty State */}
      {!loading && filteredItems.length === 0 && (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200">
          <i className="fa-solid fa-box-open text-4xl text-slate-300 mb-3"></i>
          <p className="text-slate-600 font-medium">No matching blood inventory found for selected filters.</p>
          <button
            onClick={resetFilters}
            className="mt-3 text-xs text-brand-600 font-bold hover:underline"
          >
            Clear all filters
          </button>
        </div>
      )}

      {/* INVENTORY CARD GRID matching HTML */}
      {!loading && filteredItems.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition relative flex flex-col justify-between"
            >
              <div>
                <div className="flex justify-between items-start mb-3">
                  <div className="w-12 h-12 rounded-xl bg-brand-50 border border-brand-200 flex items-center justify-center text-brand-600 font-black text-xl shadow-sm">
                    {item.bloodType}
                  </div>
                  <span
                    className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                      item.urgency === 'Critical'
                        ? 'bg-red-100 text-red-700 border border-red-200'
                        : item.urgency === 'Warning'
                        ? 'bg-amber-100 text-amber-700 border border-amber-200'
                        : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-base mb-1 truncate" title={item.hospital}>
                  {item.hospital}
                </h3>
                <p className="text-xs text-slate-500 mb-4">
                  <i className="fa-solid fa-location-dot mr-1 text-slate-400"></i>
                  {item.city}
                </p>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 mb-4 flex justify-between items-center">
                  <span className="text-xs text-slate-500 font-medium">Available Stock:</span>
                  <span className="text-lg font-extrabold text-slate-800">{item.units} Units</span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                <span>{item.lastUpdated}</span>
                <button
                  onClick={onOpenRequest}
                  className="text-brand-600 hover:text-brand-700 font-bold hover:underline"
                >
                  Reserve / Request
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
