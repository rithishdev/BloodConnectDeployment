import React, { useState } from 'react';
import { X, Heart, MapPin, Phone, Mail, CheckCircle2, ShieldCheck, Compass } from 'lucide-react';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export default function DonorRegisterModal({ isOpen, onClose, onDonorRegistered }) {
  if (!isOpen) return null;

  const [formData, setFormData] = useState({
    name: '',
    bloodGroup: 'O+',
    phone: '',
    email: '',
    city: 'Metro City',
    state: 'NY',
    address: '',
    emergencyRadiusKm: 25,
    isAvailable: true,
    availabilityStatus: 'Available',
    notes: ''
  });

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/donors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || 'Failed to register donor.');
      }

      setSuccess(true);
      if (onDonorRegistered) onDonorRegistered(data.data);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1500);
    } catch (err) {
      setErrorMsg(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal modal-md" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: 'var(--r-md)',
                background: 'var(--red-50)',
                color: 'var(--red-600)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}
            >
              <Heart size={20} />
            </div>

            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--slate-900)' }}>
                Register as an Emergency Blood Donor
              </h3>
              <p style={{ fontSize: '0.775rem', color: 'var(--slate-500)', marginTop: '2px' }}>
                Join the verified proximity network to receive alerts when your blood group is needed.
              </p>
            </div>
          </div>

          <button className="toast-close" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        {success ? (
          <div style={{ padding: '48px 24px', textAlign: 'center' }}>
            <CheckCircle2 size={54} color="var(--green-500)" style={{ margin: '0 auto 16px' }} />
            <h4 style={{ fontSize: '1.3rem', fontWeight: 800, color: 'var(--slate-900)', marginBottom: '8px' }}>
              Registration Successful!
            </h4>
            <p style={{ color: 'var(--slate-600)', fontSize: '0.9rem', maxWidth: '360px', margin: '0 auto' }}>
              Thank you for volunteering. You are now active in the automated emergency proximity dispatch network.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="modal-body">
              {errorMsg && (
                <div className="alert alert-error">
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Full Name */}
              <div className="form-group">
                <label className="form-label">
                  Full Name <span className="req">*</span>
                </label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. John Doe"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              {/* Blood Group Chips Selector */}
              <div className="form-group">
                <label className="form-label">
                  Select Blood Group <span className="req">*</span>
                </label>
                <div className="bg-chips">
                  {BLOOD_GROUPS.map((bg) => (
                    <button
                      type="button"
                      key={bg}
                      className={`bg-chip ${formData.bloodGroup === bg ? 'active' : ''}`}
                      onClick={() => setFormData({ ...formData, bloodGroup: bg })}
                    >
                      {bg}
                    </button>
                  ))}
                </div>
              </div>

              {/* Phone and Email */}
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">
                    Mobile / WhatsApp <span className="req">*</span>
                  </label>
                  <input
                    type="tel"
                    className="form-input"
                    placeholder="e.g. +1 555-0192"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Email Address (Optional)</label>
                  <input
                    type="email"
                    className="form-input"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
              </div>

              {/* City and State */}
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">
                    City / Metro Area <span className="req">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Metro City"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">State / Region</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="NY"
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  />
                </div>
              </div>

              {/* Address */}
              <div className="form-group">
                <label className="form-label">Address or Neighborhood</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. 742 Evergreen Terrace, Downtown"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                />
              </div>

              {/* Radius Slider */}
              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <label className="form-label">Alert Proximity Radius</label>
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--red-600)' }}>
                    {formData.emergencyRadiusKm} km
                  </span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="100"
                  step="5"
                  value={formData.emergencyRadiusKm}
                  onChange={(e) => setFormData({ ...formData, emergencyRadiusKm: Number(e.target.value) })}
                  style={{ width: '100%', cursor: 'pointer' }}
                />
                <div className="form-hint">
                  Receive emergency notifications when a hospital within this distance urgently needs your blood group.
                </div>
              </div>

              {/* Additional Volunteer Notes */}
              <div className="form-group">
                <label className="form-label">Volunteer Notes (Optional)</label>
                <textarea
                  className="form-textarea"
                  rows={2}
                  placeholder="e.g. Available evenings, have car for fast hospital travel..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>
            </div>

            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                <Heart size={16} />
                <span>{submitting ? 'Registering...' : 'Complete Registration'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
