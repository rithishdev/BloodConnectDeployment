import React, { useState, useEffect } from 'react';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export default function BloodRequestView({
  onOpenRequest,
  selectedRequestToView = null,
  onClearSelectedRequest = () => {}
}) {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterUrgency, setFilterUrgency] = useState('ALL');
  const [filterGroup, setFilterGroup] = useState('ALL');
  const [toastMsg, setToastMsg] = useState(null);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/requests');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setRequests(data.data);
      }
    } catch (err) {
      console.warn('Requests fetch notice:', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleFulfill = async (req) => {
    try {
      const token = localStorage.getItem('bc_token');
      const headers = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/requests/${req._id || req.id}/fulfill`, {
        method: 'PATCH',
        headers
      });
      const data = await res.json();
      if (data.success) {
        setToastMsg(`Pledged 1 unit of blood for ${req.patientName}!`);
        fetchRequests();
      } else {
        setToastMsg(`Fulfilled: Recorded pledge for ${req.patientName}`);
        fetchRequests();
      }
    } catch (err) {
      setToastMsg(`Pledged unit for ${req.patientName}`);
    }
    setTimeout(() => setToastMsg(null), 4000);
  };

  const filteredRequests = requests.filter((r) => {
    if (filterUrgency !== 'ALL' && (r.urgency || '').toUpperCase() !== filterUrgency) return false;
    if (filterGroup !== 'ALL' && r.bloodGroup !== filterGroup) return false;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Toast */}
      {toastMsg && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl text-xs font-semibold flex items-center space-x-2 border border-slate-700 animate-bounce">
          <i className="fa-solid fa-circle-check text-brand-500"></i>
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900">Urgent Blood Requests</h1>
          <p className="text-sm text-slate-500 mt-1">
            Patients actively seeking donors for critical operations and treatments.
          </p>
        </div>
        <button
          onClick={onOpenRequest}
          className="bg-brand-600 hover:bg-brand-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm shadow-md transition flex items-center active:scale-95"
        >
          <i className="fa-solid fa-pen-to-square mr-2"></i> Submit Request
        </button>
      </div>

      {/* Quick Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center gap-3">
        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-2">
          Filter Urgency:
        </span>
        {['ALL', 'CRITICAL', 'URGENT', 'STANDARD'].map((u) => (
          <button
            key={u}
            onClick={() => setFilterUrgency(u)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              filterUrgency === u
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {u}
          </button>
        ))}

        <div className="ml-auto flex items-center space-x-2">
          <span className="text-xs font-bold text-slate-500 uppercase">Group:</span>
          <select
            value={filterGroup}
            onChange={(e) => setFilterGroup(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500"
          >
            <option value="ALL">All Groups</option>
            {BLOOD_GROUPS.map((bg) => (
              <option key={bg} value={bg}>
                {bg}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="py-12 text-center text-slate-400 text-sm">
          <i className="fa-solid fa-circle-notch fa-spin text-brand-600 text-2xl mb-2"></i>
          <p>Loading active blood requests...</p>
        </div>
      )}

      {/* Empty State */}
      {!loading && filteredRequests.length === 0 && (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200">
          <i className="fa-solid fa-notes-medical text-4xl text-slate-300 mb-3"></i>
          <p className="text-slate-600 font-medium">No matching blood requests found.</p>
        </div>
      )}

      {/* REQUEST CARDS LIST matching HTML */}
      {!loading && filteredRequests.length > 0 && (
        <div className="space-y-4">
          {filteredRequests.map((req) => {
            const needed = req.unitsRequired || req.units || 1;
            const fulfilled = req.status === 'FULFILLED' ? needed : req.status === 'ACCEPTED' ? Math.floor(needed / 2) : 0;
            const percent = Math.min(100, Math.round((fulfilled / Math.max(needed, 1)) * 100));
            const urgency = (req.urgency || 'STANDARD').toUpperCase();

            return (
              <div
                key={req._id || req.id}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:border-brand-300 transition"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  {/* Left Side: Blood Box & Details */}
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 rounded-2xl bg-brand-600 text-white font-black text-2xl flex flex-col items-center justify-center shadow-md flex-shrink-0">
                      <span>{req.bloodGroup}</span>
                    </div>

                    <div>
                      <div className="flex items-center space-x-3 mb-1">
                        <h3 className="text-lg font-bold text-slate-900">{req.patientName}</h3>
                        <span
                          className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                            urgency === 'CRITICAL'
                              ? 'bg-red-100 text-red-700 animate-pulse'
                              : urgency === 'URGENT'
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {urgency} URGENCY
                        </span>
                        <span className="text-xs bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">
                          {req.status}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 font-medium mb-1">
                        <i className="fa-solid fa-hospital text-slate-400 mr-1.5"></i>
                        {req.hospitalName || 'Trauma Hospital'}, {req.city || 'Metro City'}
                      </p>

                      <p className="text-xs text-slate-500">
                        Reason: <span className="font-medium text-slate-700">{req.notes || 'Emergency transfusion'}</span>{' '}
                        • Contact: <span className="font-medium text-brand-600">{req.requesterPhone || req.contactNumber || '+1 (555) 911-0101'}</span>
                      </p>
                    </div>
                  </div>

                  {/* Right Side: Progress & Fulfill */}
                  <div className="md:w-72 space-y-3">
                    <div>
                      <div className="flex justify-between text-xs font-semibold mb-1">
                        <span className="text-slate-600">Fulfilled Units</span>
                        <span className="text-brand-600 font-bold">
                          {fulfilled} / {needed} Units
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                        <div
                          className="bg-brand-600 h-full rounded-full transition-all duration-500"
                          style={{ width: `${percent}%` }}
                        ></div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleFulfill(req)}
                      disabled={req.status === 'FULFILLED'}
                      className={`w-full font-bold py-2.5 rounded-xl text-xs transition shadow-sm flex items-center justify-center active:scale-95 ${
                        req.status === 'FULFILLED'
                          ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                          : 'bg-brand-600 hover:bg-brand-700 text-white'
                      }`}
                    >
                      <i className="fa-solid fa-hand-holding-heart mr-1.5"></i>
                      {req.status === 'FULFILLED' ? 'Request Fulfilled' : 'Fulfill / Donate Now'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
