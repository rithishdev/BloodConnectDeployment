import React, { useState, useEffect, useMemo } from 'react';

const BLOOD_GROUPS = ['ALL', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export default function HospitalsView({ onOpenRequest, userRole, onOpenAddHospital }) {
  const [hospitals, setHospitals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('ALL');
  const [selectedCity, setSelectedCity] = useState('ALL');
  const [selectedHospitalForModal, setSelectedHospitalForModal] = useState(null);
  const [phoneToast, setPhoneToast] = useState(null);

  const fetchHospitals = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/hospitals');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setHospitals(data.data);
      }
    } catch (err) {
      console.warn('Hospitals fetch notice:', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHospitals();
  }, []);

  const cities = useMemo(() => {
    const set = new Set();
    hospitals.forEach((h) => {
      if (h.city) set.add(h.city);
    });
    return Array.from(set).sort();
  }, [hospitals]);

  const filteredHospitals = useMemo(() => {
    return hospitals.filter((h) => {
      if (selectedCity !== 'ALL' && h.city !== selectedCity) return false;
      if (selectedGroup !== 'ALL') {
        const inv = h.bloodInventory || {};
        if ((inv[selectedGroup] || 0) <= 0) return false;
      }
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase();
        const matchName = h.name && h.name.toLowerCase().includes(term);
        const matchCity = h.city && h.city.toLowerCase().includes(term);
        if (!matchName && !matchCity) return false;
      }
      return true;
    });
  }, [hospitals, selectedCity, selectedGroup, searchTerm]);

  const handleCall = (h) => {
    setPhoneToast(`Connecting to ${h.name} dispatch hotline: ${h.phone || h.emergencyHotline || '911'}`);
    setTimeout(() => setPhoneToast(null), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Toast Alert */}
      {phoneToast && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl text-xs font-semibold flex items-center space-x-2 border border-slate-700 animate-bounce">
          <i className="fa-solid fa-phone-volume text-brand-500"></i>
          <span>{phoneToast}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900">Partner Hospital Network</h1>
          <p className="text-sm text-slate-500 mt-1">
            Accredited medical institutions connected directly to the BloodConnect dispatch grid.
          </p>
        </div>
        {userRole === 'admin' && (
          <button
            onClick={onOpenAddHospital}
            className="bg-brand-600 hover:bg-brand-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm shadow-md transition flex items-center active:scale-95"
          >
            <i className="fa-solid fa-plus mr-2"></i> Register New Hospital
          </button>
        )}
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center gap-4">
        <div className="flex-1 min-w-[200px]">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search hospital name or location..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
          />
        </div>

        <div className="w-44">
          <select
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
          >
            <option value="ALL">All Cities</option>
            {cities.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        <div className="w-44">
          <select
            value={selectedGroup}
            onChange={(e) => setSelectedGroup(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
          >
            <option value="ALL">All In Stock</option>
            {BLOOD_GROUPS.filter((g) => g !== 'ALL').map((bg) => (
              <option key={bg} value={bg}>
                Has {bg} Stock
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="py-12 text-center text-slate-400 text-sm">
          <i className="fa-solid fa-circle-notch fa-spin text-brand-600 text-2xl mb-2"></i>
          <p>Querying partner hospital network...</p>
        </div>
      )}

      {/* Empty State */}
      {!loading && filteredHospitals.length === 0 && (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200">
          <i className="fa-solid fa-hospital text-4xl text-slate-300 mb-3"></i>
          <p className="text-slate-600 font-medium">No partner hospitals found for current search filters.</p>
        </div>
      )}

      {/* HOSPITAL CARDS GRID matching HTML */}
      {!loading && filteredHospitals.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredHospitals.map((h) => {
            const inv = h.bloodInventory || {};
            const totalStock = Object.values(inv).reduce((sum, u) => sum + (Number(u) || 0), 0);
            const icuFree = h.icuBedsAvailable || h.icuBeds || (h.verified ? 18 : 8);

            return (
              <div
                key={h._id || h.id}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900">{h.name}</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        <i className="fa-solid fa-location-dot mr-1 text-slate-400"></i>
                        {h.address ? `${h.address}, ` : ''}{h.city || 'Metro City'}
                      </p>
                    </div>
                    <span className="text-xs font-bold bg-emerald-100 text-emerald-700 px-2.5 py-1 rounded-full">
                      {h.verified !== false ? 'Active Bank' : 'Pending Verification'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl mb-6">
                    <div>
                      <div className="text-xs text-slate-400 font-medium">Total Blood Reserve</div>
                      <div className="text-xl font-extrabold text-slate-800 mt-0.5">{totalStock} Units</div>
                    </div>
                    <div>
                      <div className="text-xs text-slate-400 font-medium">ICU Beds Free</div>
                      <div className="text-xl font-extrabold text-brand-600 mt-0.5">{icuFree} Available</div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3 pt-4 border-t border-slate-100">
                  <button
                    onClick={() => handleCall(h)}
                    className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold py-2.5 rounded-xl text-xs transition flex items-center justify-center active:scale-95"
                  >
                    <i className="fa-solid fa-phone mr-2 text-slate-500"></i>
                    {h.phone || h.emergencyHotline || '+1 (555) 019-9000'}
                  </button>
                  <button
                    onClick={() => setSelectedHospitalForModal(h)}
                    className="flex-1 bg-brand-600 hover:bg-brand-700 text-white font-semibold py-2.5 rounded-xl text-xs transition active:scale-95 text-center"
                  >
                    View Stock
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Stock Breakdown Modal */}
      {selectedHospitalForModal && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedHospitalForModal(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">{selectedHospitalForModal.name}</h3>
                <p className="text-xs text-slate-500">{selectedHospitalForModal.city}</p>
              </div>
              <button
                onClick={() => setSelectedHospitalForModal(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <i className="fa-solid fa-xmark text-lg"></i>
              </button>
            </div>

            <div className="grid grid-cols-4 gap-2 my-4">
              {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => {
                const u = selectedHospitalForModal.bloodInventory?.[bg] || 0;
                return (
                  <div key={bg} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-center">
                    <div className="text-xs font-bold text-brand-600">{bg}</div>
                    <div className="text-sm font-extrabold text-slate-900 mt-0.5">{u}</div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => {
                setSelectedHospitalForModal(null);
                onOpenRequest();
              }}
              className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-2.5 rounded-xl text-xs transition"
            >
              Post Request to This Hospital
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
