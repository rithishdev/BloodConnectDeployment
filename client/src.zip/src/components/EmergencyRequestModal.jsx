import React, { useState } from 'react';
import { X, AlertCircle, Droplet, Building2, Phone, CheckCircle2 } from 'lucide-react';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export default function EmergencyRequestModal({ isOpen, onClose, onRequestCreated }) {
  if (!isOpen) return null;

  const [formData, setFormData] = useState({
    patientName: '',
    bloodGroup: 'O-',
    unitsRequired: 2,
    hospitalName: 'St. Jude Metropolitan Trauma Center',
    hospitalAddress: '550 1st Avenue',
    city: 'Metro City',
    urgency: 'CRITICAL',
    requesterName: '',
    requesterPhone: '',
    requesterEmail: '',
    doctorName: '',
    notes: ''
  });

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [success, setSuccess] = useState(false);
  const [matchedDonorsCount, setMatchedDonorsCount] = useState(0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || 'Failed to submit emergency blood request.');
      }

      setMatchedDonorsCount(data.data?.matchedDonors?.length || 0);
      setSuccess(true);
      if (onRequestCreated) onRequestCreated(data.data);

      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 2000);
    } catch (err) {
      setErrorMsg(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal modal-md" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header" style={{ background: 'linear-gradient(to right, #fee2e2, #ffffff)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: 'var(--r-md)',
                background: 'var(--red-600)',
                color: '#ffffff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}
            >
              <AlertCircle size={20} />
            </div>

            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--red-700)' }}>
                Post Emergency Blood Request
              </h3>
              <p style={{ fontSize: '0.775rem', color: 'var(--slate-500)', marginTop: '2px' }}>
                Broadcasts high-priority alert to matched donors within local radius immediately.
              </p>
            </div>
          </div>

          <button className="toast-close" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        {success ? (
          <div style={{ padding: '48px 24px', textAlign: 'center' }}>
            <CheckCircle2 size={54} color="var(--red-600)" style={{ margin: '0 auto 16px' }} />
            <h4 style={{ fontSize: '1.3rem', fontWeight: 800, color: 'var(--slate-900)', marginBottom: '8px' }}>
              Emergency Request Dispatched!
            </h4>
            <p style={{ color: 'var(--slate-600)', fontSize: '0.9rem', marginBottom: '14px', maxWidth: '360px', margin: '0 auto' }}>
              Broadcasted across the live network. <strong>{matchedDonorsCount} compatible donor{matchedDonorsCount !== 1 ? 's' : ''}</strong> found within proximity radius.
            </p>
            <span className="badge badge-critical" style={{ marginTop: '12px' }}>
              HIGH PRIORITY BROADCAST ACTIVE
            </span>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="modal-body">
              {errorMsg && (
                <div className="alert alert-error">
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Priority Selection Cards */}
              <div className="form-group">
                <label className="form-label">
                  Urgency Priority Level <span className="req">*</span>
                </label>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px' }}>
                  {[
                    { key: 'CRITICAL', label: '🚨 CRITICAL', desc: 'Immediate Trauma / ICU' },
                    { key: 'URGENT', label: '⚠️ URGENT', desc: 'Needed within 6-12 hours' },
                    { key: 'STANDARD', label: 'STANDARD', desc: 'Elective / Next Day' }
                  ].map((opt) => (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() => setFormData({ ...formData, urgency: opt.key })}
                      style={{
                        padding: '10px 8px',
                        borderRadius: 'var(--r-md)',
                        border: formData.urgency === opt.key ? '2px solid var(--red-600)' : '1px solid var(--border)',
                        background: formData.urgency === opt.key ? 'var(--red-50)' : '#ffffff',
                        color: formData.urgency === opt.key ? 'var(--red-700)' : 'var(--slate-700)',
                        cursor: 'pointer',
                        textAlign: 'center',
                        fontSize: '0.8rem',
                        fontWeight: 700,
                        transition: 'all var(--t-fast)'
                      }}
                    >
                      <div>{opt.label}</div>
                      <div style={{ fontSize: '0.675rem', fontWeight: 500, color: 'var(--slate-500)', marginTop: '2px' }}>
                        {opt.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Blood Group Chips Selector */}
              <div className="form-group">
                <label className="form-label">
                  Required Blood Group <span className="req">*</span>
                </label>
                <div className="bg-chips">
                  {BLOOD_GROUPS.map((bg) => (
                    <button
                      type="button"
                      key={bg}
                      className={`bg-chip ${formData.bloodGroup === bg ? 'active' : ''}`}
                      onClick={() => setFormData({ ...formData, bloodGroup: bg })}
                    >
                      {bg}
                    </button>
                  ))}
                </div>
              </div>

              {/* Patient Name and Required Units */}
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">
                    Patient Full Name <span className="req">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="e.g. Alex Morgan"
                    value={formData.patientName}
                    onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">
                    Units Needed (Bags) <span className="req">*</span>
                  </label>
                  <input
                    type="number"
                    className="form-input"
                    min="1"
                    max="20"
                    value={formData.unitsRequired}
                    onChange={(e) => setFormData({ ...formData, unitsRequired: Number(e.target.value) })}
                    required
                  />
                </div>
              </div>

              {/* Hospital and City */}
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">
                    Hospital / Medical Center <span className="req">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="St. Jude Hospital"
                    value={formData.hospitalName}
                    onChange={(e) => setFormData({ ...formData, hospitalName: e.target.value })}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">
                    City <span className="req">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Metro City"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    required
                  />
                </div>
              </div>

              {/* Hospital Address / Room */}
              <div className="form-group">
                <label className="form-label">Hospital Address & Ward / Bed Details</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="550 1st Avenue, ICU Floor 3 Bed 12"
                  value={formData.hospitalAddress}
                  onChange={(e) => setFormData({ ...formData, hospitalAddress: e.target.value })}
                />
              </div>

              {/* Requester Contact */}
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">
                    Requester Name <span className="req">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Nurse or Relative Name"
                    value={formData.requesterName}
                    onChange={(e) => setFormData({ ...formData, requesterName: e.target.value })}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">
                    Emergency Contact Phone <span className="req">*</span>
                  </label>
                  <input
                    type="tel"
                    className="form-input"
                    placeholder="+1 555-9110"
                    value={formData.requesterPhone}
                    onChange={(e) => setFormData({ ...formData, requesterPhone: e.target.value })}
                    required
                  />
                </div>
              </div>

              {/* Clinical Situation Notes */}
              <div className="form-group">
                <label className="form-label">Clinical Situation / Diagnosis Notes</label>
                <textarea
                  className="form-textarea"
                  rows={2}
                  placeholder="e.g. Critical trauma bleeding in Operating Room 2. Immediate cross-match."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>
            </div>

            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                <Droplet size={16} fill="#ffffff" />
                <span>{submitting ? 'Dispatching...' : 'Broadcast Emergency Request'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
