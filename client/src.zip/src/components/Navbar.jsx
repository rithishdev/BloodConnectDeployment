import React from 'react';
import {
  Droplet,
  Search,
  FileText,
  Building2,
  ShieldCheck,
  UserPlus,
  AlertCircle,
  Bell,
  Check,
  ArrowRight,
  Activity,
  Layers,
  LogIn,
  LogOut,
  User,
  HeartHandshake,
  HeartPulse
} from 'lucide-react';

export default function Navbar({
  activeTab,
  setActiveTab,
  onOpenRegister,
  onOpenRequest,
  onOpenAuthModal,
  currentUser,
  onLogout,
  isConnected,
  pendingCriticalCount = 0,
  notifications = [],
  unreadCount = 0,
  showNotifDropdown = false,
  onToggleNotif,
  onMarkAllRead,
  onViewRequest
}) {
  return (
    <nav className="navbar">
      <div className="nav-inner">
        {/* Brand Logo */}
        <div className="nav-brand" onClick={() => setActiveTab('home')}>
          <div className="nav-brand-icon">
            <Droplet size={20} color="#ffffff" fill="#ffffff" />
          </div>
          <div className="nav-brand-text">
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span className="nav-brand-name">BloodConnect</span>
              <span className="badge badge-critical" style={{ fontSize: '0.6rem', padding: '1px 5px' }}>
                DISPATCH
              </span>
            </div>
            <span className="nav-brand-sub">Emergency Donor Platform</span>
          </div>
        </div>

        {/* Primary Navigation Links */}
        <div className="nav-links">
          <button
            className={`nav-link ${activeTab === 'home' ? 'active' : ''}`}
            onClick={() => setActiveTab('home')}
          >
            <Activity size={16} />
            <span>Home</span>
          </button>

          <button
            className={`nav-link ${activeTab === 'available' ? 'active' : ''}`}
            onClick={() => setActiveTab('available')}
          >
            <Layers size={16} />
            <span>Available Blood</span>
          </button>

          <button
            className={`nav-link ${activeTab === 'search' ? 'active' : ''}`}
            onClick={() => setActiveTab('search')}
          >
            <Search size={16} />
            <span>Search Donors</span>
          </button>

          <button
            className={`nav-link ${activeTab === 'requests' ? 'active' : ''}`}
            onClick={() => setActiveTab('requests')}
          >
            <FileText size={16} />
            <span>Blood Requests</span>
            {pendingCriticalCount > 0 && (
              <span className="nav-badge anim-pulse-ring">
                {pendingCriticalCount}
              </span>
            )}
          </button>

          <button
            className={`nav-link ${activeTab === 'hospitals' ? 'active' : ''}`}
            onClick={() => setActiveTab('hospitals')}
          >
            <Building2 size={16} />
            <span>Hospital Hub</span>
          </button>

          {/* Role specific portals */}
          {currentUser?.role === 'donor' && (
            <button
              className={`nav-link ${activeTab === 'donor-portal' ? 'active' : ''}`}
              onClick={() => setActiveTab('donor-portal')}
            >
              <HeartHandshake size={16} />
              <span>Donor Portal</span>
            </button>
          )}

          {currentUser?.role === 'patient' && (
            <button
              className={`nav-link ${activeTab === 'patient-portal' ? 'active' : ''}`}
              onClick={() => setActiveTab('patient-portal')}
            >
              <HeartPulse size={16} />
              <span>Patient Portal</span>
            </button>
          )}

          <button
            className={`nav-link ${activeTab === 'admin' ? 'active' : ''}`}
            onClick={() => setActiveTab('admin')}
          >
            <ShieldCheck size={16} />
            <span>Admin & Analytics</span>
          </button>
        </div>

        {/* Right Action Bar */}
        <div className="nav-actions">
          {/* WebSocket Status Indicator */}
          <div
            className={`nav-status ${isConnected ? 'online' : 'offline'}`}
            title={isConnected ? 'Connected to Real-time Emergency Feed' : 'Reconnecting to Emergency Bus...'}
          >
            <span className={`status-dot ${isConnected ? 'online' : 'offline'}`} />
            <span>{isConnected ? 'Live' : 'Offline'}</span>
          </div>

          {/* Notification Bell with Dropdown */}
          <div style={{ position: 'relative' }} onClick={(e) => e.stopPropagation()}>
            <button
              className="notif-btn"
              onClick={onToggleNotif}
              title="Emergency Notifications"
              aria-label="View notifications"
            >
              <Bell size={18} />
              {unreadCount > 0 && <span className="notif-count">{unreadCount}</span>}
            </button>

            {showNotifDropdown && (
              <div className="notif-dropdown">
                <div className="notif-header">
                  <span className="notif-title">Emergency Live Feed</span>
                  {unreadCount > 0 && (
                    <button
                      className="btn btn-ghost btn-xs"
                      onClick={onMarkAllRead}
                      style={{ fontSize: '0.7rem' }}
                    >
                      <Check size={12} /> Mark read
                    </button>
                  )}
                </div>

                <div className="notif-list">
                  {notifications.length === 0 ? (
                    <div className="notif-empty">No new emergency broadcasts</div>
                  ) : (
                    notifications.map((n) => (
                      <div
                        key={n.id}
                        className="notif-item"
                        onClick={() => {
                          if (n.data && onViewRequest) {
                            onViewRequest({ _id: n.requestId || n.data.id || n.data._id, ...n.data });
                          }
                        }}
                      >
                        <div className={`notif-item-icon ${n.type || 'info'}`}>
                          {n.type === 'critical' ? (
                            <AlertCircle size={16} />
                          ) : (
                            <Droplet size={16} />
                          )}
                        </div>
                        <div className="notif-item-body">
                          <div className="notif-item-title">{n.title}</div>
                          <div className="notif-item-desc">{n.message}</div>
                          <div className="notif-item-time">{n.time}</div>
                        </div>
                        {n.data && (
                          <div style={{ alignSelf: 'center', color: 'var(--slate-400)' }}>
                            <ArrowRight size={14} />
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Account / Auth Section */}
          {currentUser ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  background: 'var(--slate-100)',
                  padding: '4px 10px',
                  borderRadius: '20px',
                  cursor: 'pointer'
                }}
                onClick={() => {
                  if (currentUser.role === 'donor') setActiveTab('donor-portal');
                  else if (currentUser.role === 'patient') setActiveTab('patient-portal');
                  else if (currentUser.role === 'admin') setActiveTab('admin');
                }}
                title="Open Profile Portal"
              >
                <div style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--navy-900)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.75rem', fontWeight: 800 }}>
                  {currentUser.name ? currentUser.name[0].toUpperCase() : 'U'}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--navy-900)', lineHeight: 1.1 }}>
                    {currentUser.name?.split(' ')[0]}
                  </span>
                  <span style={{ fontSize: '0.65rem', fontWeight: 800, color: currentUser.role === 'admin' ? 'var(--red-600)' : 'var(--blue-600)', textTransform: 'uppercase' }}>
                    {currentUser.role}
                  </span>
                </div>
                {currentUser.bloodGroup && (
                  <span className="blood-group-badge" style={{ fontSize: '0.7rem', padding: '1px 6px' }}>
                    {currentUser.bloodGroup}
                  </span>
                )}
              </div>

              <button
                className="btn btn-ghost btn-xs"
                style={{ padding: '6px' }}
                onClick={onLogout}
                title="Sign Out"
              >
                <LogOut size={16} />
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <button
                className="btn btn-ghost btn-sm"
                onClick={() => onOpenAuthModal && onOpenAuthModal('donor', 'login')}
              >
                <LogIn size={15} />
                <span>Sign In</span>
              </button>
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => onOpenAuthModal && onOpenAuthModal('donor', 'register')}
              >
                <UserPlus size={15} />
                <span>Be a Donor</span>
              </button>
              <button
                className="btn btn-primary btn-sm"
                onClick={onOpenRequest}
              >
                <Droplet size={15} fill="#ffffff" />
                <span>Request Blood</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
