import React, { useState, useEffect, useMemo } from 'react';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export default function DonorSearchView({ onOpenRegister, onToggleAvailability }) {
  const [donors, setDonors] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters matching HTML
  const [filterGroup, setFilterGroup] = useState('ALL');
  const [filterCity, setFilterCity] = useState('ALL');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [contactedToast, setContactedToast] = useState(null);

  const fetchDonors = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/donors');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setDonors(data.data);
      }
    } catch (err) {
      console.warn('Donors fetch notice:', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDonors();
  }, []);

  // Extract cities
  const cities = useMemo(() => {
    const set = new Set();
    donors.forEach((d) => {
      if (d.city) set.add(d.city);
    });
    return Array.from(set).sort();
  }, [donors]);

  // Filtered donor list
  const filteredDonors = useMemo(() => {
    return donors.filter((d) => {
      if (filterGroup !== 'ALL' && d.bloodGroup !== filterGroup) return false;
      if (filterCity !== 'ALL' && d.city !== filterCity) return false;
      if (filterStatus === 'ready' && !d.isAvailable && d.availabilityStatus !== 'Available') return false;
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase();
        const nameMatch = d.name && d.name.toLowerCase().includes(term);
        const cityMatch = d.city && d.city.toLowerCase().includes(term);
        if (!nameMatch && !cityMatch) return false;
      }
      return true;
    });
  }, [donors, filterGroup, filterCity, filterStatus, searchTerm]);

  const handleContactDonor = (donor) => {
    setContactedToast(`Emergency SMS alert dispatched to ${donor.name}!`);
    setTimeout(() => setContactedToast(null), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Toast Alert */}
      {contactedToast && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl text-xs font-semibold flex items-center space-x-2 border border-slate-700 animate-bounce">
          <i className="fa-solid fa-circle-check text-brand-500"></i>
          <span>{contactedToast}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900">Registered Blood Donors Directory</h1>
          <p className="text-sm text-slate-500 mt-1">
            Connect with altruistic donors ready to donate in your emergency location.
          </p>
        </div>
        <button
          onClick={onOpenRegister}
          className="bg-brand-600 hover:bg-brand-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm shadow-md transition flex items-center active:scale-95"
        >
          <i className="fa-solid fa-heart-pulse mr-2"></i> Join As A Donor
        </button>
      </div>

      {/* DONOR SEARCH FILTERS matching HTML */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Blood Group</label>
            <select
              value={filterGroup}
              onChange={(e) => setFilterGroup(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="ALL">All Groups</option>
              {BLOOD_GROUPS.map((bg) => (
                <option key={bg} value={bg}>
                  {bg}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">City</label>
            <select
              value={filterCity}
              onChange={(e) => setFilterCity(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="ALL">All Cities</option>
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Availability Status</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="ALL">Any Status</option>
              <option value="ready">Ready to Donate</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Search Name / City</label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search donor name..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
        </div>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="py-12 text-center text-slate-400 text-sm">
          <i className="fa-solid fa-circle-notch fa-spin text-brand-600 text-2xl mb-2"></i>
          <p>Querying verified donors directory from MongoDB Atlas...</p>
        </div>
      )}

      {/* Empty State */}
      {!loading && filteredDonors.length === 0 && (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200">
          <i className="fa-solid fa-users-slash text-4xl text-slate-300 mb-3"></i>
          <p className="text-slate-600 font-medium">No donors found matching the selected filters.</p>
          <button
            onClick={() => {
              setFilterGroup('ALL');
              setFilterCity('ALL');
              setFilterStatus('ALL');
              setSearchTerm('');
            }}
            className="mt-3 text-xs text-brand-600 font-bold hover:underline"
          >
            Clear all filters
          </button>
        </div>
      )}

      {/* DONOR GRID CARDS matching HTML */}
      {!loading && filteredDonors.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDonors.map((donor) => {
            const isAvail = donor.isAvailable !== false && donor.availabilityStatus !== 'Busy';
            const badge =
              donor.totalDonations > 10 ? 'Hero Donor' : donor.totalDonations > 3 ? 'Regular' : 'Active Donor';

            return (
              <div
                key={donor._id || donor.id}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="w-14 h-14 rounded-2xl bg-brand-600 text-white font-black text-2xl flex items-center justify-center shadow-md">
                      {donor.bloodGroup}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-lg leading-snug">{donor.name}</h3>
                      <div className="flex items-center space-x-2 mt-0.5">
                        <span className="text-xs bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">
                          {badge}
                        </span>
                        <span className="text-xs text-slate-400">
                          {donor.totalDonations || 1} Donations
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs text-slate-600 mb-6 bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Location:</span>
                      <span className="font-semibold text-slate-800">{donor.city || 'Metro City'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Last Donation:</span>
                      <span className="font-semibold text-slate-800">
                        {donor.lastDonatedDate ? new Date(donor.lastDonatedDate).toLocaleDateString() : 'Eligible'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Status:</span>
                      <span className={`font-bold ${isAvail ? 'text-emerald-600' : 'text-slate-400'}`}>
                        {isAvail ? '● Available Now' : '○ Resting Period'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <button
                    onClick={() => handleContactDonor(donor)}
                    className="w-full bg-slate-900 hover:bg-brand-600 text-white font-semibold py-2.5 rounded-xl text-xs transition flex items-center justify-center active:scale-95"
                  >
                    <i className="fa-solid fa-envelope mr-2"></i> Send Urgent Request
                  </button>
                  {onToggleAvailability && (
                    <button
                      onClick={() => onToggleAvailability(donor._id || donor.id)}
                      className="w-full text-slate-400 hover:text-slate-600 text-[11px] font-medium py-1 text-center"
                    >
                      Toggle Availability
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
