import React, { useState } from 'react';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const CITIES = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'Metro City'];

const COMPATIBILITY_DATA = {
  'O-': {
    canGiveTo: ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
    canReceiveFrom: ['O-'],
    type: 'Universal Donor',
    description: 'Can give to all 8 blood groups. Essential for acute trauma transfusions.'
  },
  'O+': {
    canGiveTo: ['O+', 'A+', 'B+', 'AB+'],
    canReceiveFrom: ['O+', 'O-'],
    type: 'Most Common Red Blood Cell Type',
    description: 'Can donate to any Rh-positive recipient (over 80% of population).'
  },
  'A-': {
    canGiveTo: ['A-', 'A+', 'AB-', 'AB+'],
    canReceiveFrom: ['A-', 'O-'],
    type: 'Rare Negative Blood Type',
    description: 'Can donate red blood cells to A and AB patients of both Rh factors.'
  },
  'A+': {
    canGiveTo: ['A+', 'AB+'],
    canReceiveFrom: ['A+', 'A-', 'O+', 'O-'],
    type: 'Common Positive Blood Type',
    description: 'Vital blood type for oncology, emergency room, and surgical procedures.'
  },
  'B-': {
    canGiveTo: ['B-', 'B+', 'AB-', 'AB+'],
    canReceiveFrom: ['B-', 'O-'],
    type: 'Rare Donor Type (< 2% Population)',
    description: 'High clinical demand due to scarcity in blood banking reserves.'
  },
  'B+': {
    canGiveTo: ['B+', 'AB+'],
    canReceiveFrom: ['B+', 'B-', 'O+', 'O-'],
    type: 'Essential Positive Type',
    description: 'High utilization rate across critical trauma departments.'
  },
  'AB-': {
    canGiveTo: ['AB-', 'AB+'],
    canReceiveFrom: ['AB-', 'A-', 'B-', 'O-'],
    type: 'Rarest Blood Type (< 1% Population)',
    description: 'Universal plasma donor and highly specialized transfusion profile.'
  },
  'AB+': {
    canGiveTo: ['AB+'],
    canReceiveFrom: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
    type: 'Universal Recipient',
    description: 'Can receive red blood cells from every blood group in emergency surgeries.'
  }
};

export default function HomeView({
  analytics,
  onOpenRegister,
  onOpenRequest,
  onNavigateTab,
  onViewRequest
}) {
  const [quickGroup, setQuickGroup] = useState('');
  const [quickCity, setQuickCity] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('O-');

  const summary = analytics?.summary || {
    totalDonors: 24500,
    availableDonors: 18200,
    totalRequests: 4,
    criticalRequests: 1,
    fulfilledRequests: 2,
    totalHospitals: 150
  };

  const criticalInventory = [
    { bloodType: 'O-', units: 3, hospital: 'St. Jude Metropolitan Trauma', city: 'Metro City', status: 'Critical Low', urgency: 'Critical' },
    { bloodType: 'AB-', units: 2, hospital: 'City Presbyterian Hospital', city: 'Metro City', status: 'Critical Low', urgency: 'Critical' },
    { bloodType: 'B-', units: 4, hospital: 'Bellevue Health Center', city: 'Metro City', status: 'Low Stock', urgency: 'Warning' },
    { bloodType: 'A-', units: 6, hospital: 'General Memorial Hospital', city: 'Metro City', status: 'Low Stock', urgency: 'Warning' }
  ];

  const handleQuickSearch = () => {
    onNavigateTab('available');
  };

  const compat = COMPATIBILITY_DATA[selectedGroup] || COMPATIBILITY_DATA['O-'];

  return (
    <div className="space-y-12 pb-12">
      {/* ─── HERO SECTION ──────────────────────────────────────────────── */}
      <section className="relative bg-gradient-to-br from-slate-900 via-brand-950 to-slate-900 text-white overflow-hidden py-14 lg:py-20 rounded-b-3xl sm:rounded-3xl shadow-xl mx-0 sm:mx-4 mt-0 sm:mt-4">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ef4444_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Left Copy & Search */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center px-3.5 py-1.5 rounded-full bg-brand-500/20 border border-brand-500/30 text-brand-300 text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-brand-500 mr-2 animate-ping"></span>
                Live National Emergency Blood Network
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
                Connecting Blood Donors With{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-red-200">
                  Critical Patients
                </span>
              </h1>

              <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
                Every 2 seconds someone needs blood. Join our intelligent matching system that bridges verified donors, trauma hospitals, and recipients within minutes.
              </p>

              {/* Quick Search Bar */}
              <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/20 shadow-2xl max-w-xl mx-auto lg:mx-0">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <select
                    value={quickGroup}
                    onChange={(e) => setQuickGroup(e.target.value)}
                    className="bg-slate-800 text-white text-xs rounded-xl px-3 py-2.5 border border-slate-700 focus:outline-none focus:border-brand-500"
                  >
                    <option value="">Blood Group (Any)</option>
                    {BLOOD_GROUPS.map((bg) => (
                      <option key={bg} value={bg}>
                        {bg}
                      </option>
                    ))}
                  </select>

                  <select
                    value={quickCity}
                    onChange={(e) => setQuickCity(e.target.value)}
                    className="bg-slate-800 text-white text-xs rounded-xl px-3 py-2.5 border border-slate-700 focus:outline-none focus:border-brand-500"
                  >
                    <option value="">Select City</option>
                    {CITIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>

                  <button
                    onClick={handleQuickSearch}
                    className="bg-brand-600 hover:bg-brand-500 text-white font-bold py-2.5 px-4 rounded-xl shadow-lg transition flex items-center justify-center text-xs active:scale-95"
                  >
                    <i className="fa-solid fa-magnifying-glass mr-2"></i> Find Stock
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2">
                <button
                  onClick={onOpenRequest}
                  className="bg-brand-600 hover:bg-brand-700 text-white font-semibold px-5 py-2.5 rounded-xl text-xs shadow-md transition flex items-center active:scale-95"
                >
                  <i className="fa-solid fa-hand-holding-medical mr-2"></i> Request Blood Urgently
                </button>
                <button
                  onClick={() => onNavigateTab('search')}
                  className="bg-white hover:bg-slate-100 text-slate-900 font-semibold px-5 py-2.5 rounded-xl text-xs shadow-md transition flex items-center active:scale-95"
                >
                  <i className="fa-solid fa-users mr-2 text-brand-600"></i> Find Nearby Donors
                </button>
                <button
                  onClick={onOpenRegister}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold px-5 py-2.5 rounded-xl text-xs transition border border-slate-700 flex items-center active:scale-95"
                >
                  <i className="fa-solid fa-heart-pulse mr-2 text-brand-500"></i> Become Donor
                </button>
              </div>

              {/* Trust Badges */}
              <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-5 text-xs text-slate-400">
                <div className="flex items-center">
                  <i className="fa-solid fa-shield-halved text-brand-400 mr-2"></i> 100% Verified Banks
                </div>
                <div className="flex items-center">
                  <i className="fa-solid fa-bolt text-brand-400 mr-2"></i> Instant Dispatch
                </div>
                <div className="flex items-center">
                  <i className="fa-solid fa-lock text-brand-400 mr-2"></i> Secure Data
                </div>
              </div>
            </div>

            {/* Right Card: Critical Shortage Alert */}
            <div className="lg:col-span-5">
              <div className="bg-slate-800/80 backdrop-blur-xl border border-slate-700 p-6 rounded-3xl shadow-2xl">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-white text-base sm:text-lg flex items-center">
                    <i className="fa-solid fa-circle-radiation text-brand-500 mr-2 animate-pulse"></i> Critical Shortage Alert
                  </h3>
                  <span className="text-[11px] bg-slate-700 px-2.5 py-0.5 rounded-full text-slate-300 font-semibold">
                    Live Status
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  {criticalInventory.map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-900/80 p-3 rounded-2xl border border-slate-700/60 hover:border-brand-500/50 transition cursor-pointer"
                      onClick={() => onNavigateTab('available')}
                    >
                      <div className="flex justify-between items-start">
                        <span className="text-2xl font-black text-brand-500">{item.bloodType}</span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            item.urgency === 'Critical'
                              ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                              : 'bg-amber-500/20 text-amber-400'
                          }`}
                        >
                          {item.status}
                        </span>
                      </div>
                      <p className="text-xs font-semibold text-slate-200 mt-2 truncate">{item.hospital}</p>
                      <p className="text-[11px] text-slate-400">{item.units} Units remaining</p>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => onNavigateTab('available')}
                  className="w-full bg-slate-700 hover:bg-slate-600 text-slate-200 font-semibold py-2.5 rounded-xl text-xs transition flex items-center justify-center active:scale-95"
                >
                  View Complete National Blood Inventory <i className="fa-solid fa-arrow-right ml-2"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── REALTIME COUNTERS STRIP ───────────────────────────────────── */}
      <section className="bg-brand-600 text-white py-8 border-y border-brand-700 shadow-inner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-2xl sm:text-4xl font-extrabold">
                {(summary.totalDonors || 24500).toLocaleString()}+
              </div>
              <div className="text-xs sm:text-sm text-brand-100 font-medium">Registered Donors</div>
            </div>
            <div>
              <div className="text-2xl sm:text-4xl font-extrabold">
                {(summary.availableDonors || 18200).toLocaleString()}+
              </div>
              <div className="text-xs sm:text-sm text-brand-100 font-medium">Available Donors</div>
            </div>
            <div>
              <div className="text-2xl sm:text-4xl font-extrabold">
                {summary.totalHospitals || 150}+
              </div>
              <div className="text-xs sm:text-sm text-brand-100 font-medium">Partner Hospitals</div>
            </div>
            <div>
              <div className="text-2xl sm:text-4xl font-extrabold">100%</div>
              <div className="text-xs sm:text-sm text-brand-100 font-medium">Verified Blood Units</div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── HOW IT WORKS / SIMPLIFIED PROCESS ─────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-xs font-bold text-brand-600 uppercase tracking-widest mb-1">
            Simplified Process
          </h2>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            How BloodConnect Saves Lives
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          <div className="bg-white p-7 rounded-3xl border border-slate-200/80 shadow-sm hover:shadow-md transition text-center">
            <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-2xl flex items-center justify-center text-2xl font-bold mx-auto mb-5">
              1
            </div>
            <h4 className="text-lg font-bold text-slate-900 mb-2">Request or Register</h4>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Patients or hospitals post urgent blood requirements while donors register their availability and blood group.
            </p>
          </div>

          <div className="bg-white p-7 rounded-3xl border border-slate-200/80 shadow-sm hover:shadow-md transition text-center">
            <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-2xl flex items-center justify-center text-2xl font-bold mx-auto mb-5">
              2
            </div>
            <h4 className="text-lg font-bold text-slate-900 mb-2">Instant Smart Match</h4>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Our automated dispatch system matches patient needs with nearby compatible blood banks and eligible active donors instantly.
            </p>
          </div>

          <div className="bg-white p-7 rounded-3xl border border-slate-200/80 shadow-sm hover:shadow-md transition text-center">
            <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-2xl flex items-center justify-center text-2xl font-bold mx-auto mb-5">
              3
            </div>
            <h4 className="text-lg font-bold text-slate-900 mb-2">Fulfill & Save Life</h4>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Direct dispatch or scheduled donation at the accredited hospital ensures verified blood reaches the recipient on time.
            </p>
          </div>
        </div>
      </section>

      {/* ─── INTERACTIVE BLOOD GROUP COMPATIBILITY GUIDE ───────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <h3 className="text-xl font-bold text-slate-900">
                Blood Group Transfusion Compatibility Guide
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Select a blood group to see clinical compatibility for donors and recipients.
              </p>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {BLOOD_GROUPS.map((bg) => (
                <button
                  key={bg}
                  onClick={() => setSelectedGroup(bg)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    selectedGroup === bg
                      ? 'bg-brand-600 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {bg}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-50 p-6 rounded-2xl border border-slate-100">
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase">Selected Group</div>
              <div className="text-4xl font-black text-brand-600 mt-1">{selectedGroup}</div>
              <p className="text-xs font-semibold text-slate-800 mt-2">{compat.type}</p>
              <p className="text-xs text-slate-500 mt-1">{compat.description}</p>
            </div>

            <div>
              <div className="text-xs font-bold text-slate-400 uppercase mb-2">
                Can Safely Donate To ({compat.canGiveTo.length} groups)
              </div>
              <div className="flex flex-wrap gap-2">
                {compat.canGiveTo.map((g) => (
                  <span
                    key={g}
                    className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200"
                  >
                    {g}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs font-bold text-slate-400 uppercase mb-2">
                Can Safely Receive From ({compat.canReceiveFrom.length} groups)
              </div>
              <div className="flex flex-wrap gap-2">
                {compat.canReceiveFrom.map((g) => (
                  <span
                    key={g}
                    className="px-2.5 py-1 rounded-lg text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200"
                  >
                    {g}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
